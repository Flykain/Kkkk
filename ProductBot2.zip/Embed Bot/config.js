module.exports = {
	embedColor: "#2f3136",
	Users: {
		owners: ["Owner ID, doesn't affect anything tho"],
	},
	Client: {
		TOKEN: "Bot token",
		ID: "Guild ID",
	},
};
