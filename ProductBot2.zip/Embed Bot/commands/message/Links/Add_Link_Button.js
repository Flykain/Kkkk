const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, BitField, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: "Add_Link_Button",
    type: 3,
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
        //Check user has admnistrator permission
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply({ content: "You don't have permission to use this command!", ephemeral: true });
        }
        const modal = new ModalBuilder()
            .setCustomId(`add_link_button.${interaction.targetMessage.id}`)
            .setTitle('Add Link Button');
            
        const button_name = new TextInputBuilder()
            .setCustomId('button_name')
            .setLabel("Button Name")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("Click here!")
            .setMinLength(1)
            .setMaxLength(10)
            .setRequired(true);

        const button_link = new TextInputBuilder()
            .setCustomId('button_link')
            .setLabel("Link")
            .setStyle(TextInputStyle.Short)
            .setPlaceholder("https://beasthub.com")
            .setMinLength(1)
            .setMaxLength(50)
            .setRequired(true);
        
        const ActionRow1 = new ActionRowBuilder().addComponents(button_name);
        const ActionRow2 = new ActionRowBuilder().addComponents(button_link);
        modal.addComponents(ActionRow1, ActionRow2);

        await interaction.showModal(modal);
    },
};
