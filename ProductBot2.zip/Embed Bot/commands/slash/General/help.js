const { EmbedBuilder } = require("discord.js");

module.exports = {
    name: "help",
    description: "Get help about the bot",
    type: 1,
    options: [],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "SendMessages"
    },
    run: async (client, interaction, config, db) => {
        await interaction.deferReply({ ephemeral: true });

        const embed = new EmbedBuilder()
            .setTitle("Help")
            .addFields([
                {
                    name: "General",
                    value: "embed add, embed remove, help, restore_moneyspent_data"
                },
                {
                    name: "Product",
                    value: "product add, remove, send"
                },
                {
                    name: "Money",
                    value: "moneyspent add, remove, view"
                },
                {
                    name: "Settings",
                    value: "moneyspentrole add, remove, list, Add_Link_Button, json add, remove, list"
                }
            ])
            .setColor(client.config.embedColor)
            .setTimestamp()
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))

        await interaction.editReply({ embeds: [embed] });
    },
};
