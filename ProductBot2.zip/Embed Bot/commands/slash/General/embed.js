const { EmbedBuilder, ApplicationCommandOptionType, ChannelType } = require("discord.js");

const fs = require("fs");
const ms = require("ms");

module.exports = {
    name: "embed",
    description: "Create an embed",
    type: 1,
    options: [
        {
            name: "add",
            description: "Add a embed with Resend Feature",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "json",
                    description: "Add a embed with Resend Feature",
                    type: ApplicationCommandOptionType.String,
                    autocomplete: true,
                    required: true
                },
                {
                    name: "duration",
                    description: "Duration of the embed To Resend, Eg. 1m, 1h, 1d",
                    type: ApplicationCommandOptionType.String,
                    required: false
                }
            ]
        },
        {
            name: "remove",
            description: "Remove a embed with Resend Feature",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "channel",
                    description: "Channel of the embed",
                    type: ApplicationCommandOptionType.Channel,
                    channel_types: [ChannelType.GuildText],
                    required: false
                },
            ]
        }
    ],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
        await interaction.deferReply({ ephemeral: true });

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "add") {
            const json = interaction.options.getString("json");
            const duration = interaction.options.getString("duration");
            if (duration) {
                if (isNaN(ms(duration))) {
                    return interaction.editReply({ content: "Invalid duration!" });
                }
            }
            const message = require(`../../../json/${json}.json`)?.backups[0]?.messages[0]?.data;
            if (!message) {
                return interaction.editReply({ content: "Invalid json!" });
            }
            const channel = interaction.channel;
            const msg = await channel.send(message);
            const data = {
                channel: channel.id,
                message: msg.id,
                duration: duration ? ms(duration) : 0,
                json: JSON.stringify(message),
                time: Date.now()
            };
            if (duration) {
                await db.set(`embed_${channel.id}`, data);
                const embeds = await db.get("embeds");
                if (Array.isArray(embeds)) {
                    await db.set("embeds", [channel.id]);
                } else {
                    await db.push("embeds", channel.id);
                }
            }
            await interaction.editReply({ content: "Embed created!" });
        }
        if (subcommand === "remove") {
            let channel = interaction.options.getChannel("channel");
            if (!channel) {
                channel = interaction.channel;
            }
            await db.delete(`embed_${channel.id}`);
            const embeds = await db.get("embeds");
            if (Array.isArray(embeds)) {
                await db.set("embeds", embeds.filter((id) => id !== channel.id));
            }
            await interaction.editReply({ content: "Embed removed!" });
        }
    },
    /**
     * 
     * @param {*} client 
     * @param {import('discord.js').AutocompleteInteraction} interaction 
     * @param {*} config 
     * @param {*} db 
     * @returns 
     */
    autocomplete: async (client, interaction, config, db) => {
        const focusedValue = interaction.options.getFocused();
        const jsons = fs.readdirSync(`./json/`).filter(file => file.endsWith('.json'));
        let options = [];

        if (!jsons) return interaction.respond([]);

        for (let file of jsons) {
            options.push({
                name: file.replace(".json", ""),
                value: file.replace(".json", "")
            });
        }

        const filtered = options.filter((option) => option.name.toLowerCase().includes(focusedValue.toLowerCase()));
        return interaction.respond(options);
    }
};