const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: "restore_moneyspent_data",
    description: "Use /money_spent_role clear to create new amount roles for this server",
    type: 1,
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
        await interaction.deferReply({ ephemeral: true });

        //check bot has admin perms
        if (!interaction.guild.me.permissions.has('ADMINISTRATOR')) {
            return interaction.editReply({
                content: 'I need the `ADMINISTRATOR` permission to run this command'
            });
        }

        const spent_data = await db.get('money_spent_amount');

        if (!Array.isArray(spent_data)) {
            const embed = new EmbedBuilder()
                .setTitle('Error')
                .setDescription('You have not set a money spent role yet. Please set one using `/settings set_money_spent_role`')
                .setColor(client.config.embedColor)
                .setTimestamp();

            return interaction.editReply({
                embeds: [embed]
            });
        }

        const data = await db.get('money_spent');

        if (!data) {
            const embed = new EmbedBuilder()
                .setTitle('Error')
                .setDescription('There is no data to restore')
                .setColor(client.config.embedColor)
                .setTimestamp();

            return interaction.editReply({
                embeds: [embed]
            });
        }

        const guild = interaction.guild;
        let count = 0;

        for (const [id, amount] of Object.entries(data)) {
            const member = guild.members.cache.get(id);
            let isHigher = false;
            let highamount = [];
            spent_data.forEach(async (a) => {
                if (amount >= a) {
                    isHigher = true;
                    highamount.push(a);
                }
            });
            if (isHigher) {
                let roles = [];

                for (let i = 0; i < highamount.length; i++) {
                    const role = await db.get(`money_spent_role.${highamount[i]}`);
                    await member.roles.add(role);
                }
                count++;
            }
        }

        const embed = new EmbedBuilder()
            .setTitle('Success')
            .setDescription(`Successfully restored the role of ${count} users`)
            .setColor(client.config.embedColor)
            .setTimestamp();

        return interaction.editReply({
            embeds: [embed]
        });
    }
};