const { EmbedBuilder, ApplicationCommandOptionType, AttachmentBuilder } = require('discord.js');

const https = require('https');
const fs = require('fs');

module.exports = {
    name: "json",
    description: "Create an embed",
    type: 1,
    options: [
        {
            name: "add",
            description: "Add a Json File to database (Make Sure To Remove .json from the file name)",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "json",
                    description: "Add a embed with Resend Feature",
                    type: ApplicationCommandOptionType.Attachment,
                    required: true
                },
                {
                    name: "name",
                    description: "Name of the embed",
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        },
        {
            name: "remove",
            description: "Remove a embed with Resend Feature",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "name",
                    description: "Name of the embed",
                    type: ApplicationCommandOptionType.String,
                    autocomplete: true,
                    required: true
                }
            ]
        },
        {
            name: "list",
            description: "List all embeds",
            type: ApplicationCommandOptionType.Subcommand
        }
    ],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    /**
     * 
     * @param {import('discord.js').Client} client 
     * @param {import('discord.js').ChatInputCommandInteraction} interaction 
     * @param {*} config 
     * @param {*} db 
     */
    run: async (client, interaction, config, db) => {
        await interaction.deferReply({ ephemeral: true });

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "add") {
            const json = interaction.options.getAttachment("json");
            const name = interaction.options.getString("name");

            const Attachment = AttachmentBuilder.from(json);

            const file = fs.createWriteStream(`./json/${name}.json`);
            const request = https.get(Attachment.attachment, function (response) {
                response.pipe(file);
            });

            interaction.editReply({ embeds: [new EmbedBuilder().setTitle("Success!").setDescription(`Successfully added the json file \`${name}.json\`!`).setColor("Green")] });
        } else if (subcommand === "remove") {
            const name = interaction.options.getString("name");
            // Check if the file exists
            const jsons = fs.readdirSync(`./json/`).filter(file => file.endsWith('.json'));

            if (!jsons) return interaction.editReply({ embeds: [new EmbedBuilder().setTitle("Error!").setDescription(`There are no json files!`).setColor("Red")] });
            if (!jsons.includes(`${name}.json`)) return interaction.editReply({ embeds: [new EmbedBuilder().setTitle("Error!").setDescription(`The json file \`${name}.json\` doesn't exist!`).setColor("Red")] });

            // Delete the file
            const filePath = `./json/${name}.json`;
            fs.unlinkSync(filePath);

            interaction.editReply({ embeds: [new EmbedBuilder().setTitle("Success!").setDescription(`Successfully removed the json file \`${name}.json\`!`).setColor("Green")] });
        }
        else if (subcommand === "list") {
            const jsons = fs.readdirSync(`./json/`).filter(file => file.endsWith('.json'));

            if (!jsons) return interaction.editReply({ embeds: [new EmbedBuilder().setTitle("Error!").setDescription(`There are no json files!`).setColor("Red")] });

            let embed = new EmbedBuilder()
                .setTitle("JSON Files")
                .setDescription(`Here are all the json files!`)
                .setColor("Green");

            for (let file of jsons) {
                embed.addFields({ name: `${file.replace(".json", "")}`, value: `\`${file}\``, inline: true });
            }

            interaction.editReply({ embeds: [embed] });
        }
    },
    autocomplete: async (client, interaction, config, db) => {
        const focusedValue = interaction.options.getFocused();
        const jsons = fs.readdirSync(`./json/`).filter(file => file.endsWith('.json'));
        let options = [];

        if (!jsons) return interaction.respond([]);

        for (let file of jsons) {
            options.push({
                name: file.replace(".json", ""),
                value: file.replace(".json", "")
            });
        }

        const filtered = options.filter((option) => option.name.toLowerCase().includes(focusedValue.toLowerCase()));
        return interaction.respond(options);
    }
}
