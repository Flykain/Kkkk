const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');

module.exports = {
    name: "money_spent_role",
    description: "money spent role command",
    type: 1,
    options: [
        {
            name: "add",
            description: "Add a role to be given to users who spend a certain amount of money",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "role",
                    description: "The role to be given to users who spend a certain amount of money",
                    type: ApplicationCommandOptionType.Role,
                    required: true
                },
                {
                    name: "amount",
                    description: "The amount of money a user must spend to get the role",
                    type: ApplicationCommandOptionType.Integer,
                    required: true
                }
            ]
        },
        {
            name: "remove",
            description: "Remove a role from being given to users who spend a certain amount of money",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "amount",
                    description: "The amount of money a user must spend to get the role",
                    type: ApplicationCommandOptionType.Integer,
                    required: true
                }
            ]
        },
        {
            name: "list",
            description: "List all the roles that are given to users who spend a certain amount of money",
            type: ApplicationCommandOptionType.Subcommand
        },
        {
            name: "clear",
            description: "Clear all the roles that are given to users who spend a certain amount of money",
            type: ApplicationCommandOptionType.Subcommand
        }
    ],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
        const subCommand = interaction.options.getSubcommand();

        if (subCommand === "add") {
            const role = interaction.options.getRole("role");
            const amount = interaction.options.getInteger("amount");

            await interaction.deferReply({ ephemeral: true });
            const embed = new EmbedBuilder();
            embed.setColor(client.config.embedColor);
            embed.setTitle("Money Spent Role");
            embed.setDescription(`The role ${role} will be given to users who spend $${amount} or more money`);

            const data = await db.get("money_spent_amount");
            if (Array.isArray(data) && data.includes(amount)) {
                return await interaction.editReply({ content: "That amount is already in use", ephemeral: true });
            }

            if (Array.isArray(data)) {
                const added = [...data, amount];
                const sorted = added.sort((a, b) => a - b);
                const nodups = [...new Set(sorted)];
                await db.set("money_spent_amount", nodups);
                await db.set(`money_spent_role.${amount}`, role.id)
            } else {
                await db.set("money_spent_amount", [amount]);
                await db.set(`money_spent_role.${amount}`, role.id)
            }
            await interaction.editReply({ embeds: [embed] });
        } else if (subCommand === "remove") {
            const amount = interaction.options.getInteger("amount");
            await interaction.deferReply({ ephemeral: true });
            const embed = new EmbedBuilder();
            embed.setColor(client.config.embedColor);
            embed.setTitle("Money Spent Role");
            embed.setDescription(`The role will no longer be given to users who spend $${amount} or more money`);

            const data = await db.get("money_spent_amount");
            if (!Array.isArray(data) || !data.includes(amount)) {
                return await interaction.editReply({ content: "That amount is not in use", ephemeral: true });
            }

            const removed = data.filter(a => a !== amount);
            const sorted = removed.sort((a, b) => a - b);
            const nodups = [...new Set(sorted)];
            await db.set("money_spent_amount", nodups);
            await db.delete(`money_spent_role.${amount}`);
            await interaction.editReply({ embeds: [embed] });
        } else if (subCommand === "list") {
            await interaction.deferReply({ ephemeral: true });
            const embed = new EmbedBuilder();
            embed.setColor(client.config.embedColor);
            embed.setTitle("Money Spent Role");

            const data = await db.get("money_spent_amount");
            if (!Array.isArray(data) || data.length === 0) {
                embed.setDescription("There are no roles set to be given to users who spend a certain amount of money");
                return await interaction.editReply({ embeds: [embed] });
            }

            let description = "";
            for (const amount of data) {
                const role = interaction.guild.roles.cache.get(await db.get(`money_spent_role.${amount}`));
                description += `**$${amount}**: ${role}\n`;
            }
            embed.setDescription(description);
            await interaction.editReply({ embeds: [embed] });
        } else if (subCommand === "clear") {
            await interaction.deferReply({ ephemeral: true });
            const embed = new EmbedBuilder();
            embed.setColor(client.config.embedColor);
            embed.setTitle("Money Spent Role");
            embed.setDescription("All the roles that are given to users who spend a certain amount of money have been cleared");

            await db.delete("money_spent_amount");
            await db.delete("money_spent_role");
            await interaction.editReply({ embeds: [embed] });
        }
    }
};