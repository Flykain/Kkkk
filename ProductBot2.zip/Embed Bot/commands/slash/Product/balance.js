const { EmbedBuilder, ApplicationCommandOptionType, ChannelType } = require("discord.js");

const fs = require("fs");

module.exports = {
    name: "balance",
    description: "Check your balance",
    type: 1,
    options: [
        {
            name: "user",
            description: "User to check balance",
            type: ApplicationCommandOptionType.User,
            required: false
        }
    ],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "SendMessages"
    },
    run: async (client, interaction, config, db) => {
        await interaction.deferReply({ ephemeral: true });
        const user = interaction.options.getUser("user") || interaction.user;
        const data = await db.get(`money_spent.${user.id}`);
        if (!data) {
            await db.set(`money_spent.${user.id}`, 0);
        }
        const embed = new EmbedBuilder()
            .setTitle('Balance')
            .setDescription(`**${user}** has **$${data || 0}**`)
            .setColor(client.config.embedColor)
            .setTimestamp();
        interaction.editReply({ embeds: [embed] });
    }
};