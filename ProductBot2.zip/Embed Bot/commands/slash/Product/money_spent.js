const { EmbedBuilder, ApplicationCommandOptionType } = require('discord.js');

module.exports = {
	name: "money_spent",
	description: "Get the amount of money you have spent",
	type: 1,
	options: [
		{
			name: "add",
			description: "Add money to a user spent amount",
			type: ApplicationCommandOptionType.Subcommand,
			options: [
				{
					name: "user",
					description: "The user to add money to",
					type: ApplicationCommandOptionType.User,
					required: true
				},
				{
					name: "amount",
					description: "The amount of money to add",
					type: ApplicationCommandOptionType.Integer,
					required: true
				}
			]
		},
		{
			name: "remove",
			description: "Remove money from a user spent amount",
			type: ApplicationCommandOptionType.Subcommand,
			options: [
				{
					name: "user",
					description: "The user to remove money from",
					type: ApplicationCommandOptionType.User,
					required: true
				},
				{
					name: "amount",
					description: "The amount of money to remove",
					type: ApplicationCommandOptionType.Integer,
					required: true
				}
			]
		},
		{
			name: "view",
			description: "View the amount of money a user has spent",
			type: ApplicationCommandOptionType.Subcommand,
			options: [
				{
					name: "user",
					description: "The user to view the amount of money they have spent",
					type: ApplicationCommandOptionType.User,
					required: true
				}
			]
		}
	],
	permissions: {
		DEFAULT_MEMBER_PERMISSIONS: "Administrator"
	},
	run: async (client, interaction, config, db) => {
		const subCommand = interaction.options.getSubcommand();
		const user = interaction.options.getUser('user');
		const amount = interaction.options.getInteger('amount');
		const member = interaction.guild.members.cache.get(user.id);
		const channel = interaction.channel;

		if (!interaction.member.permissions.has('ADMINISTRATOR')) {
			const embed = new EmbedBuilder()
				.setTitle('Error')
				.setDescription('You do not have permission to use this command')
				.setColor(client.config.embedColor)
				.setTimestamp();

			return interaction.reply({
				embeds: [embed]
			});
		}

		const spent_data = await db.get('money_spent_amount');

		if (!Array.isArray(spent_data)) {
			const embed = new EmbedBuilder()
				.setTitle('Error')
				.setDescription('You have not set a money spent role yet. Please set one using `/set_money_spent_role`')
				.setColor(client.config.embedColor)
				.setTimestamp();

			return interaction.reply({
				embeds: [embed]
			});
		}

		if (subCommand === 'add') {
			await interaction.deferReply({ ephemeral: true });

			const user = interaction.options.getUser('user');
			const amount = interaction.options.getInteger('amount');
			const data = await db.get(`money_spent.${user.id}`);

			if (!data) {
				await db.set(`money_spent.${user.id}`, amount);
				const money_spent_amount = await db.get('money_spent_amount');
				const userAmount = await db.get(`money_spent.${user.id}`);
				let isHigher = false;
				let highamount = [];
				money_spent_amount.forEach(async (a) => {
					if (userAmount >= a) {
						isHigher = true;
						highamount.push(a);
					}
				});
				if (!isHigher) {
					return interaction.editReply({
						embeds: [new EmbedBuilder()
							.setTitle('Success')
							.setDescription(`Added $${amount} to ${user}'s spent amount`)
							.setColor(client.config.embedColor)
							.setTimestamp()]
					});
				}
				let roles = [];
				for (let i = 0; i < highamount.length; i++) {
					const role = await db.get(`money_spent_role.${highamount[i]}`);
					await member.roles.add(role);
					roles.push(member.guild.roles.cache.get(role));
				}
				const embed = new EmbedBuilder()
					.setTitle('Success')
					.setDescription(`Added $${amount} to ${user}'s spent amount and gave them the ${roles.join(', ')} role`)
					.setColor(client.config.embedColor)

				await channel.send({
					embeds: [embed]
				});
			} else {
				await db.set(`money_spent.${user.id}`, data + amount);
				const money_spent_amount = await db.get('money_spent_amount');
				const userAmount = await db.get(`money_spent.${user.id}`);
				let isHigher = false;
				let highamount = []
				money_spent_amount.forEach(async (a) => {
					if (userAmount >= a) {
						isHigher = true;
						highamount.push(a);
					}
				});
				if (!isHigher) {
					return interaction.editReply({
						embeds: [new EmbedBuilder()
							.setTitle('Success')
							.setDescription(`Added $${amount} to ${user}'s spent amount`)
							.setColor(client.config.embedColor)
							.setTimestamp()]
					});
				}
				let roles = [];

				for (let i = 0; i < highamount.length; i++) {
					const role = await db.get(`money_spent_role.${highamount[i]}`);
					await member.roles.add(role);
					roles.push(member.guild.roles.cache.get(role));
				}
				const embed = new EmbedBuilder()
					.setTitle('Success')
					.setDescription(`Added $${amount} to ${user}'s spent amount and gave them the ${roles.join(', ')} role`)
					.setColor(client.config.embedColor)

				await channel.send({
					embeds: [embed]
				});

				interaction.editReply({
					embeds: [new EmbedBuilder()
						.setTitle('Success')
						.setDescription(`Added $${amount} to ${user}'s spent amount`)
						.setColor(client.config.embedColor)
						.setTimestamp()]
				});
			}
		} else if (subCommand === 'remove') {
			await interaction.deferReply({ ephemeral: true });
			const user = interaction.options.getUser('user');
			const amount = interaction.options.getInteger('amount');
			const data = await db.get(`money_spent.${user.id}`);

			if (!data) {
				await db.set(`money_spent.${user.id}`, 0);
				const embed = new EmbedBuilder()
					.setTitle('Error')
					.setDescription(`The user ${user} has not spent any money`)
					.setColor(client.config.embedColor)
					.setTimestamp();

				return interaction.editReply({
					embeds: [embed]
				});
			} else {
				await db.set(`money_spent.${user.id}`, data - amount);
				const money_spent_amount = await db.get('money_spent_amount');
				let isLower = false;
				let lowamount = [];
				money_spent_amount.forEach(async (a) => {
					if ((data - amount) < a) {
						isLower = true;
						lowamount.push(a);
					}
				});
				if (!isLower) {
					return interaction.editReply({
						embeds: [new EmbedBuilder()
							.setTitle('Success')
							.setDescription(`Removed $${amount} from ${user}'s spent amount`)
							.setColor(client.config.embedColor)
							.setTimestamp()]
					});
				}
				let roles = [];

				for (let i = 0; i < lowamount.length; i++) {
					const role = await db.get(`money_spent_role.${lowamount[i]}`);
					await member.roles.remove(role);
					roles.push(member.guild.roles.cache.get(role));
				}

				const embed = new EmbedBuilder()
					.setTitle('Success')
					.setDescription(`Removed $${amount} from ${user}'s spent amount`)

				await channel.send({
					embeds: [embed]
				});

				interaction.editReply({
					embeds: [new EmbedBuilder()
						.setTitle('Success')
						.setDescription(`Removed $${amount} from ${user}'s spent amount`)
						.setColor(client.config.embedColor)
						.setTimestamp()]
				});
			}
		} else if (subCommand === 'view') {
			await interaction.deferReply();
			const data = await db.get(`money_spent.${user.id}`);
			if (!data) {
				await db.set(`money_spent.${user.id}`, 0);
			}
		}

		const data = await db.get(`money_spent.${user.id}`);

		const ResultEmbed = new EmbedBuilder()
			.setTitle('Money Spent')
			.setDescription(`The user ${user} has spent $${data} money`)
			.setColor(client.config.embedColor)
			.setTimestamp();

		await interaction.editReply({
			embeds: [ResultEmbed]
		});
	}
};