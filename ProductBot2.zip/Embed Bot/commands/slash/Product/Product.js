const { EmbedBuilder, ApplicationCommandOptionType, ButtonBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');

const fs = require('fs');

module.exports = {
    name: "product",
    description: "Product Commands",
    type: 1,
    options: [
        {
            name: "add",
            description: "Add a product",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "name",
                    description: "The name of the product",
                    type: ApplicationCommandOptionType.String,
                    required: true
                },
                {
                    name: "response",
                    description: "The response of the product",
                    type: ApplicationCommandOptionType.String,
                    autocomplete: true,
                    required: true
                },
                {
                    name: "emoji",
                    description: "The emoji of the product",
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        },
        {
            name: "remove",
            description: "Remove a product",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "name",
                    description: "The name of the product",
                    type: ApplicationCommandOptionType.String,
                    autocomplete: true,
                    required: true
                }
            ]
        },
        {
            name: "message",
            description: "Set the message of the product panel",
            type: ApplicationCommandOptionType.Subcommand,
            options: [
                {
                    name: "title",
                    description: "The message of the product panel",
                    type: ApplicationCommandOptionType.String,
                    required: true
                },
                {
                    name: "description",
                    description: "The description of the product panel",
                    type: ApplicationCommandOptionType.String,
                    required: true
                },
                {
                    name: "color",
                    description: "The color of the product panel",
                    type: ApplicationCommandOptionType.String,
                    required: true
                },
                {
                    name: "thumbnail",
                    description: "The thumbnail of the product panel",
                    type: ApplicationCommandOptionType.String,
                    required: true
                },
                {
                    name: "image",
                    description: "The image of the product panel",
                    type: ApplicationCommandOptionType.String,
                    required: true
                }
            ]
        },
        {
            name: "send",
            description: "Send the product panel",
            type: ApplicationCommandOptionType.Subcommand
        }
    ],
    permissions: {
        DEFAULT_MEMBER_PERMISSIONS: "Administrator"
    },
    run: async (client, interaction, config, db) => {
        await interaction.deferReply({ ephemeral: true });
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === "add") {
            const name = interaction.options.getString("name");
            const response = interaction.options.getString("response");
            const emoji = interaction.options.getString("emoji");

            const data = await db.get("products");

            if (data?.length >= 15) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("You can only have 15 products!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            }

            if (data && data[name]) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("This product already exists!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            }

            if (emoji && !emoji.match(/<a?:\w+:\d+>/)) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("Please provide a valid emoji!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            }

            const message = require(`../../../json/${response}.json`)?.backups[0]?.messages[0]?.data;
            if (!message) {
                return interaction.editReply({ content: "Invalid json!" });
            }

            if (!data) {
                db.set("products", [
                    {
                        name: name,
                        response: JSON.stringify(message),
                        emoji: emoji
                    }
                ]);
            } else {
                db.push("products", {
                    name: name,
                    response: JSON.stringify(message),
                    emoji: emoji
                });
            };

            interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`Successfully added the product \`${name}\`!`)
                        .setColor("Green")
                ]
            });
        } else if (subcommand === "remove") {
            const name = interaction.options.getString("name");

            const data = await db.get("products");

            if (!data) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("There are no products!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            }

            const index = data.findIndex(product => product.name === name);

            if (index === -1) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("This product does not exist!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            }

            await db.set("products", data.filter(product => product.name !== name));

            interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`Successfully removed the product \`${name}\`!`)
                        .setColor("Green")
                ]
            });
        } else if (subcommand === "send") {
            const data = await db.get("products");

            if (!data) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("There are no products!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            };

            const message = await db.get("productMessage");

            if (!message) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("There is no product message! Please set one with `/product message`")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            };
            const embed = new EmbedBuilder()
                .setTitle(message.title)
                .setDescription(message.description)
                .setColor(message.color)
                .setThumbnail(message.thumbnail)
                .setImage(message.image)
                .setTimestamp();

            const SelectMenu = new StringSelectMenuBuilder()
                .setCustomId("products")
                .setPlaceholder("Select a product")
                .setMinValues(1)
                .setMaxValues(1);

            SelectMenu.addOptions(data.map((product, index) => {
                return {
                    label: product.name,
                    value: product.name,
                    emoji: product.emoji
                };
            }));

            const ActionRow = new ActionRowBuilder()
                .addComponents([SelectMenu]);

            await interaction.channel.send({
                embeds: [embed],
                components: [ActionRow]
            });

            interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription("Successfully sent the product panel!")
                        .setColor("Green")
                ]
            });
        } else if (subcommand === "message") {
            const title = interaction.options.getString("title");
            const description = interaction.options.getString("description");
            const color = interaction.options.getString("color");
            const thumbnail = interaction.options.getString("thumbnail");
            const image = interaction.options.getString("image");

            const urlRegex = /(https?:\/\/[^\s]+)/g;

            if (thumbnail && !thumbnail.match(urlRegex)) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("The thumbnail must be a valid URL!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            };

            if (image && !image.match(urlRegex)) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("The image must be a valid URL!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            };

            if (color && !color.match(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/)) {
                return interaction.editReply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription("The color must be a valid hex color!")
                            .setColor("Red")
                    ],
                    ephemeral: true
                });
            };

            await db.set("productMessage", {
                title: title,
                description: description,
                color: color,
                thumbnail: thumbnail,
                image: image
            });

            interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription("Successfully set the product message!")
                        .setColor("Green")
                ]
            });
        };
    },
    autocomplete: async (client, interaction, config, db) => {
        const subcommand = interaction.options.getSubcommand();
        const focusedValue = interaction.options.getFocused();

        if (subcommand === "remove") {
            const products = await db.get("products");
            if (!products) return interaction.respond([]);
            const filtered = products.filter(choice => choice.name.startsWith(focusedValue));
            await interaction.respond(
                filtered.map(choice => ({ name: choice.name, value: choice.name })),
            );
        } else if (subcommand === "add") {
            const jsons = fs.readdirSync(`./json/`).filter(file => file.endsWith('.json'));
            let options = [];

            if (!jsons) return interaction.respond([]);

            for (let file of jsons) {
                options.push({
                    name: file.replace(".json", ""),
                    value: file.replace(".json", "")
                });
            }

            const filtered = options.filter((option) => option.name.toLowerCase().includes(focusedValue.toLowerCase()));
            return interaction.respond(options);
        }
    }
}
