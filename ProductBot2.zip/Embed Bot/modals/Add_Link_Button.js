const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require("discord.js");

module.exports = {
    id: "add_link_button",
    run: async (client, interaction, config, db, id) => {
        const channel = interaction.guild.channels.cache.get(interaction.channelId);
        const message = await channel.messages.fetch(id);

        const button_name = interaction.fields.getTextInputValue('button_name');
        const button_link = interaction.fields.getTextInputValue('button_link');

        const linkRegex = /^(https?:\/\/)?(www\.)?([a-zA-Z0-9]+)\.([a-zA-Z0-9]+)(\/[a-zA-Z0-9]+)*$/;

        if (!linkRegex.test(button_link)) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription('The link you provided is not valid')
                    .setColor('Red')
            ],
            ephemeral: true
        });

        if (message.author.id !== client.user.id) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription('You can only use this modal in a message sent by the bot')
                    .setColor('Red')
            ],
            ephemeral: true
        });
        
        const Button = new ButtonBuilder()
            .setLabel(button_name)
            .setStyle(ButtonStyle.Link)
            .setURL(button_link);

        const old_content = message.content;
        const old_embeds = message.embeds;
        const old_buttons = message?.components[0]?.components;
        const isMaxed = old_buttons?.length >= 5;

        if (isMaxed) return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setDescription('You can only have 5 buttons in a message')
                    .setColor('Red')
            ],
            ephemeral: true
        });

        if (old_buttons) {
            old_buttons.push(Button);
        }

        const ActionRow = new ActionRowBuilder()
            .addComponents(old_buttons || Button);

        await message.edit({
            content: old_content,
            embeds: old_embeds,
            components: [ActionRow]
        }); 

        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle('Success')
                    .setDescription('The button has been added to the message')
                    .setColor('Green')
            ],
            ephemeral: true
        });

    },
};
