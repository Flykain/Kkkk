const { EmbedBuilder } = require("discord.js");
const client = require("../../index");
const config = require("../../config")
const { QuickDB } = require("quick.db");
const db = new QuickDB();

module.exports = {
	name: "interactionCreate"
};

client.on('interactionCreate', async (interaction) => {
	if (interaction.isChatInputCommand()) {
		const command = client.slash_commands.get(interaction.commandName);

		if (!command) {
			return interaction.editReply({
				embeds: [
					new EmbedBuilder()
						.setDescription('Something went wrong... Probably the command is not owned by the bot.')
						.setColor('Red')
				],
				ephemeral: true
			});
		}
		try {
			command.run(client, interaction, config, db);
		} catch (e) {
			console.error(e)
		};
	};
	if (interaction.isAutocomplete()) {
		const command = client.slash_commands.get(interaction.commandName);

		if (!command) {
			console.log('Something went wrong... Probably the command is not owned by the bot.');
			return;
		}

		try {
			await command.autocomplete(client, interaction, config, db);
		} catch (error) {
			console.error(error);
		}
	};

	if (interaction.isUserContextMenuCommand()) { // User:
		const command = client.user_commands.get(interaction.commandName);

		if (!command) return;

		try {
			command.run(client, interaction, config, db);
		} catch (e) {
			console.error(e)
		};
	};

	if (interaction.isMessageContextMenuCommand()) { // Message:
		const command = client.message_commands.get(interaction.commandName);

		if (!command) return;

		try {
			command.run(client, interaction, config, db);
		} catch (e) {
			console.error(e)
		};
	};

	if (interaction.isModalSubmit()) { // Modals:
		const spt = interaction.customId.split('.');
		const modal = client.modals.get(spt[0]);

		if (!modal) return interaction.reply({
			embeds: [
				new EmbedBuilder()
					.setDescription('Something went wrong... Probably the Modal ID is not defined in the modals handler.')
					.setColor('Red')
			],
			ephemeral: true
		});

		try {
			modal.run(client, interaction, config, db, spt[1]);
		} catch (e) {
			console.error(e)
		};
	}
	if (interaction.isStringSelectMenu()) {
		if (interaction.customId !== "products") return;
		const product = interaction.values[0];
		const data = await db.get(`products`);

		if (!data) return interaction.reply({
			embeds: [
				new EmbedBuilder()
					.setDescription('Something went wrong... Probably the product is not defined in the database.')
					.setColor('Red')
			],
			ephemeral: true
		});

		const productData = data.find(x => x.name === product);

		if (!productData) return interaction.reply({
			embeds: [
				new EmbedBuilder()
					.setDescription('Something went wrong... Probably the product is not defined in the database.')
					.setColor('Red')
			],
			ephemeral: true
		});

		let response = JSON.parse(productData.response);

		response['ephemeral'] = true;

		interaction.reply(response);
		interaction.message.edit({
			embeds: interaction.message.embeds,
			components: interaction.message.components,
			content: interaction.message.content
		});
	}
});

