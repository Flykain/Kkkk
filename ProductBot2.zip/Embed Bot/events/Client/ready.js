const client = require("../../index");
const colors = require("colors");
const { EmbedBuilder } = require("discord.js");
const { QuickDB } = require("quick.db");
const db = new QuickDB();

module.exports = {
	name: "ready.js"
};

client.on('ready', async () => {
	console.log("\n" + `[READY] ${client.user.tag} is up and ready to go.`.brightGreen);

	setInterval(async () => {
		const embeds = await db.get("embeds");
		if (embeds && embeds.length > 0) {
			for (const embed of embeds) {
				const embedData = await db.get(`embed_${embed}`);
				const channel = client.channels.cache.get(embed);
				if (channel) {
					if ((Date.now() - embedData.time) >= embedData.duration) {
						const msg = await channel.messages.fetch(embedData.message);
						if (msg) {
							const newMsg = await channel.send(JSON.parse(embedData.json));
							await msg.delete({ timeout: 3000 });
							await db.set(`embed_${embed}`, {
								channel: embedData.channel,
								message: newMsg.id,
								time: Date.now(),
								duration: embedData.duration,
								json: embedData.json
							});
						}
					}
				}
			}
		}
	}, 1000 * 60 * 10);
})
